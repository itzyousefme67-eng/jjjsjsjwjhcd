package cc.silk.mixin;

import cc.silk.SilkClient;
import cc.silk.module.Module;
import cc.silk.gui.newgui.NewClickGUI;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {
    @Shadow
    @Final
    private MinecraftClient client;

    // In 1.21.4+ the Keyboard#onKey signature changed:
    //   OLD: (long window, int key, int scancode, int action, int mods)
    //   NEW: (long window, int action, KeyInput keyInput)
    // KeyInput is a record of {key, scancode, modifiers}; the standalone int is now the GLFW action.
    @Inject(method = "onKey", at = @At("HEAD"))
    private void onPress(long window, int action, KeyInput keyInput, CallbackInfo ci) {
        if (window == this.client.getWindow().getHandle()) {
            if (this.client.currentScreen == null && action == GLFW.GLFW_PRESS) {
                // Handle Right Shift directly to open the GUI.
                int key = keyInput.key();
                if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
                    if (SilkClient.INSTANCE != null && this.client.player != null) {
                        this.client.setScreen(new cc.silk.gui.ClickGui());
                    }
                    return;
                }

                if (SilkClient.INSTANCE == null || SilkClient.INSTANCE.moduleManager == null) {
                    return;
                }

                for (Module module : SilkClient.INSTANCE.moduleManager.getModules()) {
                    if (key != module.getKey()) {
                        continue;
                    }

                    if (module.getKeybindSetting().isHoldMode()) {
                        if (!module.isEnabled()) {
                            module.setEnabled(true);
                        }
                    } else {
                        module.toggle();
                    }
                }
            } else if (this.client.currentScreen == null && action == GLFW.GLFW_RELEASE) {
                // Release hold-mode binds only; do not re-trigger toggle binds.
                if (SilkClient.INSTANCE == null || SilkClient.INSTANCE.moduleManager == null) {
                    return;
                }
                int key = keyInput.key();
                for (Module module : SilkClient.INSTANCE.moduleManager.getModules()) {
                    if (key == module.getKey()
                            && module.getKeybindSetting().isHoldMode()
                            && module.isEnabled()) {
                        module.setEnabled(false);
                    }
                }
            }
        }
    }
}
